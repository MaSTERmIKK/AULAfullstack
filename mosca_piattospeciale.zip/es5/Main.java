import java.util.Scanner;

public class Main {
    static boolean exit = true;
    public static void main(String[] args) {
        Menu menu = new Menu();
        int totale = 0;

        while(exit == true){
            totale = totale + menu.scegliMenu();
            
            Scanner altro = new Scanner(System.in); // Create a Scanner object
            System.out.println("Vuoi altro?");

            String altro_ = altro.nextLine(); // Read user input

            if (altro_.toLowerCase().equals("no")){
                exit = false;
            }
        }
        
        System.out.println("Il totale è di " + totale + " euro");
    
    }

}