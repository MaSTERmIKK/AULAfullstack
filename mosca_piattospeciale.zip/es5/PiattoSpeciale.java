public class PiattoSpeciale {
    public String tipo;
    private String carne;
    private int prezzo;

    public int getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(int prezzo) {
        this.prezzo = this.prezzo + prezzo;
        System.out.println("costo panino: " + this.prezzo);
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        if (tipo == "1"){
            this.tipo = "normale";
        }else{
            this.tipo = "sesamo";
        }
        
    }

    public String getCarne() {
        return carne;
    }

    public void setCarne(String carne) {
        if (carne.equals("manzo")){
            this.setPrezzo(4);
        }else if (carne.equals("maiale")){
            this.setPrezzo(5);
        }else{
            System.out.println("carne non disponibile");
        }
        this.carne = carne;
    }

}
