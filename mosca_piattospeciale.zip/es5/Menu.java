import java.util.Scanner;

public class Menu {
    public int scegliMenu() {
        PiattoSpeciale piattoSpeciale = new PiattoSpeciale();

        Scanner tipoScanner = new Scanner(System.in);
        Scanner carneScan = new Scanner(System.in);
        Scanner altraCarneScan = new Scanner(System.in);

        System.out.println("Scegli il tipo di panino (1: normale, 2: sesamo)");

        String tipo = tipoScanner.nextLine();
        piattoSpeciale.setTipo(tipo);


        String altraCarne = "si";

        while (altraCarne.equals("si")) {
            System.out.println("Scegli il tipo di carne");
            piattoSpeciale.setCarne(carneScan.nextLine());

            System.out.println("Vuoi altra carne? (si/no)");
            altraCarne = altraCarneScan.nextLine().toLowerCase();
        }
        
        tipoScanner.close();
        carneScan.close();
        altraCarneScan.close();

        return piattoSpeciale.getPrezzo() + 1;
    }
}
